"""
Exit Manager - Monitors positions and decides when to exit
"""
import asyncio
import logging
import time
from typing import Dict, List, Optional
from dataclasses import dataclass
import httpx

from .position_tracker import Position

logger = logging.getLogger(__name__)


@dataclass
class ExitDecision:
    """Exit decision for a position"""
    symbol: str
    action: str  # PARTIAL_CLOSE, CLOSE, HOLD
    percentage: float  # 0.0-1.0
    reason: str
    hold_score: int
    exit_score: int
    factors: Dict


class ExitManager:
    """
    Monitors positions and decides when to exit
    
    Uses:
    - AI Engine exit evaluator (Phase 3D)
    - Stop loss triggers
    - Take profit triggers
    - Time-based exits
    """
    
    def __init__(
        self,
        redis_client,
        ai_engine_url: str = "http://127.0.0.1:8001",
        use_ai_exits: bool = True
    ):
        self.redis = redis_client
        self.ai_engine_url = ai_engine_url
        self.use_ai_exits = use_ai_exits
        self.http_client = httpx.AsyncClient(timeout=5.0)
        
        # Statistics
        self.evaluations_count = 0
        self.exits_triggered = 0
        
        logger.info(f"[ExitManager] Initialized (AI exits: {use_ai_exits})")
    
    async def evaluate_position(self, position: Position) -> ExitDecision:
        """
        Evaluate position for exit
        
        Priority:
        1. Stop loss check (immediate)
        2. Take profit check (immediate)
        3. AI exit evaluation (dynamic)
        """
        self.evaluations_count += 1
        
        # Check stop loss
        sl_triggered = self._check_stop_loss(position)
        if sl_triggered:
            return ExitDecision(
                symbol=position.symbol,
                action="CLOSE",
                percentage=1.0,
                reason="stop_loss_triggered",
                hold_score=0,
                exit_score=10,
                factors={"sl_triggered": True}
            )
        
        # Check take profit
        tp_triggered = self._check_take_profit(position)
        if tp_triggered:
            return ExitDecision(
                symbol=position.symbol,
                action="CLOSE",
                percentage=1.0,
                reason="take_profit_triggered",
                hold_score=0,
                exit_score=10,
                factors={"tp_triggered": True}
            )
        
        # AI exit evaluation
        if self.use_ai_exits and position.R_net > 0.5:
            ai_decision = await self._call_ai_exit_evaluator(position)
            if ai_decision:
                return ai_decision
        
        # Default: hold
        return ExitDecision(
            symbol=position.symbol,
            action="HOLD",
            percentage=0.0,
            reason="no_exit_conditions",
            hold_score=5,
            exit_score=0,
            factors={}
        )
    
    def _check_stop_loss(self, position: Position) -> bool:
        """Check if stop loss triggered"""
        if position.stop_loss == 0:
            return False
        
        if position.side == "LONG":
            return position.current_price <= position.stop_loss
        else:
            return position.current_price >= position.stop_loss
    
    def _check_take_profit(self, position: Position) -> bool:
        """Check if take profit triggered"""
        if position.take_profit == 0:
            return False
        
        if position.side == "LONG":
            return position.current_price >= position.take_profit
        else:
            return position.current_price <= position.take_profit
    
    async def _call_ai_exit_evaluator(self, position: Position) -> Optional[ExitDecision]:
        """
        Call AI Engine exit evaluator API
        
        Returns:
            ExitDecision if AI available, None otherwise
        """
        try:
            payload = {
                "symbol": position.symbol,
                "side": position.side,
                "entry_price": position.entry_price,
                "current_price": position.current_price,
                "position_qty": position.position_qty,
                "entry_timestamp": position.entry_timestamp,
                "age_sec": position.age_sec,
                "R_net": position.R_net,
                "R_history": position.R_history,
                "entry_regime": position.entry_regime,
                "entry_confidence": position.entry_confidence,
                "peak_price": position.peak_price
            }
            
            response = await self.http_client.post(
                f"{self.ai_engine_url}/api/v1/evaluate-exit",
                json=payload
            )
            
            if response.status_code != 200:
                logger.warning(f"[ExitManager] AI Engine returned {response.status_code}")
                return None
            
            data = response.json()
            
            return ExitDecision(
                symbol=position.symbol,
                action=data.get("action", "HOLD"),
                percentage=data.get("percentage", 0.0),
                reason=data.get("reason", "ai_evaluation"),
                hold_score=data.get("hold_score", 0),
                exit_score=data.get("exit_score", 0),
                factors=data.get("factors", {})
            )
        
        except httpx.TimeoutException:
            logger.warning("[ExitManager] AI Engine timeout")
            return None
        except Exception as e:
            logger.error(f"[ExitManager] AI Engine call failed: {e}")
            return None
    
    async def close(self):
        """Close HTTP client"""
        await self.http_client.aclose()

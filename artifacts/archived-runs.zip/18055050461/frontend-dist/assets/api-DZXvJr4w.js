async function t(n){try{return await n.json()}catch{return}}export{t as safeJson};
